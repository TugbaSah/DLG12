package vehicle;


//import io.github.bonigarcia.wdm.WebDriverManager;
//import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class FindVehicle {


    public static void main(String[] args) {

       user_find_the_vehicle_by_using_credentials();
       // user_verify_if_the_vehicle_is_existing();

}


    public static void user_find_the_vehicle_by_using_credentials() {

        //String url="https://covercheck.vwfsinsuranceportal.co.uk";//First I tried direct connection
        //but I could't and I opened google and searched in google but still not found
        String url="https://google.com";


        //Finding driver
        System.setProperty("webdriver.chrome.driver"
                ,"/Users/ufuksahinduran/Documents/Selenium dependencies/drivers/chromedriver");//driver path

        /*
        You can run this code in any IDE by changing driver path
         */

        //Setting up driver
        WebDriver driver = new ChromeDriver();

        //Navigating url (google)
        driver.get(url);

        //Finding searchButton Web element
        WebElement searchbutton = driver.findElement(By.xpath("//input[@class=\"gLFyf gsfi\"]"));

        //Sending inputin the google search button
        searchbutton.sendKeys("https://covercheck.vwfsinsuranceportal.co.uk", Keys.ENTER);

        //Finding the website
        WebElement insurancePortal=driver.findElement(By.xpath("//h3[contains(text(),'Drive Away Cover Checker')]"));

        //driver clicks to website but not opening
        insurancePortal.click();


        try{
            Thread.sleep(2000);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }//just to see what is happening on this step



        //Registration number Web Element--> I could just a few minutes
        // and I found these 2 webelements
        WebElement regNumInput= driver.findElement(By.id("vehicleReg"));
        WebElement findVehicleBtn= driver.findElement(By.xpath("//div[@id=\"icon\"]"));

        //input Reg number into the RegNumberWebElement
        regNumInput.sendKeys("OV12UYY");

        //Clicking to findVehicleWebElement
        findVehicleBtn.click();



        driver.quit();
    }


    public static void user_verify_if_the_vehicle_is_existing(){
        //after I logged in the vehicle I will assert if the vehicle is already exist.
    }










   // ####################################################
    // This is with bonigarcia and junit that I added, tried and deleted dependencies


    /*
    @Test
    public  void deneme(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver=new ChromeDriver();

        driver.get("https://google.com");
        WebElement searchbutton = driver.findElement(By.xpath("//input[@class=\"gLFyf gsfi\"]"));
        searchbutton.sendKeys("https://covercheck.vwfsinsuranceportal.co.uk", Keys.ENTER);

        WebElement insurancePortal=driver.findElement(By.xpath("//h3[contains(text(),'Drive Away Cover Checker')]"));
        insurancePortal.click();
        driver.quit();

    }

     */

}
